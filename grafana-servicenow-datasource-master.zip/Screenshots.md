## Dashboard Showcase

![image](https://user-images.githubusercontent.com/153843/90498026-b5f2d100-e13f-11ea-9068-08f496d1df30.png)
![image](https://user-images.githubusercontent.com/153843/90538813-f7eb3980-e176-11ea-9a51-bf9ee1be2a78.png)

## Annotation examples

![image](https://user-images.githubusercontent.com/153843/90492179-cd7a8b80-e138-11ea-9cf7-ca4e74abdcdc.png)
![image](https://user-images.githubusercontent.com/153843/90487040-cbf99500-e131-11ea-8151-0ed9f5b55d73.png)

## Editor examples

![image](https://user-images.githubusercontent.com/153843/90187853-6a909980-ddb2-11ea-8040-57794a211be7.png)
![image](https://user-images.githubusercontent.com/153843/90187918-8136f080-ddb2-11ea-8599-c4823f9dc101.png)

