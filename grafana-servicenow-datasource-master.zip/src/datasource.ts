import { flatten, cloneDeep, last } from 'lodash';
import { getSeriesNameFromRow } from './utils';
import { DataSourceApi } from './grafana';
import { ServiceNowInstance } from './servicenow/ServiceNowInstance';
import { ServiceNowDocQuery, ServiceNowAggregationQuery } from './servicenow/ServiceNowQuery';

export class Datasource extends DataSourceApi {
  private serviceNowInstance: ServiceNowInstance;

  /** @ngInject */
  constructor(private instanceSettings: any, private templateSrv: any) {
    super(instanceSettings);
    this.serviceNowInstance = new ServiceNowInstance(this.instanceSettings, this.templateSrv);
  }

  query(options: any) {
    const promises: any[] = [];
    const snOptions = cloneDeep(options);
    const isTimeSeriesFormat: boolean =
      options &&
      options.targets &&
      options.targets[0] &&
      options.targets[0].servicenow &&
      options.targets[0].servicenow.resultFormat === 'timeseries';
    if (snOptions.targets.length > 0) {
      const snIncidentPromise = this.serviceNowInstance.query(snOptions);
      if (snIncidentPromise) {
        promises.push(snIncidentPromise);
      }
    }
    return Promise.all(promises).then(results => {
      console.log(";lakjsdf;klj");
      if (isTimeSeriesFormat) {
        const data: any[] = [];
        results.forEach(result => {
          result.rows.forEach((row: any) => {
            data.push({
              target: getSeriesNameFromRow(row),
              datapoints: [[last(row), options.range.to]],
            });
          });
        });
        return { data };
      } else {
        return { data: flatten(results) };
      }
    });
  }

  annotationQuery(options: any) {
    options.annotation.query = this.templateSrv.replace(options.annotation.query, {}, 'csv');
    const annotationQuery = {
      range: options.range,
      rangeRaw: options.rangeRaw,
      annotation: options.annotation,
    };
    return this.serviceNowInstance
      .annotationsQuery(annotationQuery)
      .then((result: any) => {
        console.log('a;lkdjf;alkjsdf');
        return result;
      })
      .catch((ex: any) => {
        console.error(ex);
        return [];
      });
  }

  metricFindQuery(query: string) {
    if (!query) {
      return Promise.resolve([]);
    }
    if (query && query.startsWith('list(') && query.endsWith(')')) {
      const queryItems = query
        .replace(`list(`, ``)
        .slice(0, -1)
        .split(',');
      const tableName = queryItems[0];
      console.log(queryItems[0])
      const fieldName = queryItems[1];
      const querystring = queryItems.filter((item, index) => index > 1).join(',');
      console.log(querystring);
      const snQuery = new ServiceNowAggregationQuery(tableName, [fieldName], querystring, 'true', [], 'all');
      return this.serviceNowInstance
        .getServiceNowResults(snQuery)
        .then(res => {
          return Promise.resolve(
            res.data.result.map((r: any) => {
              const text = r && r.groupby_fields && r.groupby_fields[0] ? r.groupby_fields[0].display_value || r.groupby_fields[0].value : '';
              const value = r && r.groupby_fields && r.groupby_fields[0] ? r.groupby_fields[0].value : '';
              return { text, value };
            })
          );
        })
        .catch((ex: any) => {
          console.error(ex);
          return Promise.resolve([]);
        });
    }
    return Promise.resolve([]);
  }

  testDatasource() {
    return new Promise(async (resolve: any, reject: any) => {
      const query = new ServiceNowDocQuery('table/schema');
      this.serviceNowInstance
        .getServiceNowResults(query, 0)
        .then((result: any) => {
          if (result && result.status === 200 && result.data && result.data.result) {
            resolve({ message: `Successfully Connected ServiceNow.${result.data.result.length} tables found.`, status: 'success' });
          } else {
            console.error(result);
            reject({ message: 'Failed to Connect ServiceNow', status: 'error' });
          }
        })
        .catch((ex: any) => {
          console.error(ex);
          reject({ message: 'Failed to Connect ServiceNow', status: 'error' });
        });
    });
  }
}
